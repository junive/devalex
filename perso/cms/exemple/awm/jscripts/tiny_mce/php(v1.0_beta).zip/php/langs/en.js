// UK lang variables

tinyMCE.addToLang('php',{
title : 'Insert / edit PHP',
desc : 'Insert / edit PHP',
file : 'PHP Code',
size : 'Layout Size',
list : 'PHP Assets',
props : 'PHP properties',
general : 'General',
reset : 'Reset Changes',
asset_desc : "Description"
});

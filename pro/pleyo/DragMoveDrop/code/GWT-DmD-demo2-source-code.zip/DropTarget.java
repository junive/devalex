/*
 * Copyright 2007 Alex Gorisse.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.alex_gorisse.gwt.dragmovedrop;

import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.dnd.DragListenerCollection;
import com.google.gwt.user.client.dnd.DropListener;
import com.google.gwt.user.client.dnd.DropListenerCollection;
import com.google.gwt.user.client.dnd.MouseDragGestureRecognizer;
import com.google.gwt.user.client.dnd.SourcesDropEvents;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

/**
 * This is the class for all Drag Behavior, around the different listener.
 * 
 * For example : 
 * <code>
 *  // First instantiate the manager
 *  DropTarget.DragManager myManager = myDrop.getManager();
 *  // Then apply a behavior (this one allow you to drag a panel)
 *  myManager.setDroppable(myPan);
 * </code>
 */
public class DropTarget implements DropListener{

  private boolean container = false, update = false, exit = false, exitTarget = false;
  private boolean insertOnDrop = false, insertOnEnter = false;
  private int left = 0, top = 0, right = 0, bottom = 0;
  private MouseDragGestureRecognizer mouse = null;
  private Widget widget, drop, overflow;;
  private DropListenerCollection dropCollection, dropListener;
  private Vector childMap, banList;
  private DragListenerCollection dragListener = null;
  private static HashMap dropTargetList;
  private static Label labelo = new Label();
  
  private DropListener childListeners= new DropListener() {
    public void onDrop(Widget sender, Widget source) {  
      insertOnDrop(sender, source);
      if (insertOnEnter) {
        labelo.removeFromParent();
      }
    }
    public void onDropEnter(Widget sender, Widget source) {  
      insertOnEnter(sender, source); 
    }

    public void onDropExit(Widget sender, Widget source) { }
    public void onDropOver(Widget sender, Widget source) { }
  };
  
  public DropTarget(Widget wid) {
    this.widget = wid;   
    if (widget instanceof SourcesDropEvents) {
      ((SourcesDropEvents) widget).addDropListener(this);
    }
  }
  
  public DropTarget(Widget wid, DropListener dropListener) {
    this.widget = wid;
    dropCollection = new DropListenerCollection();
    dropCollection.add(this, widget);
    dropCollection.add(dropListener, widget);
    if (dropTargetList == null) {
      dropTargetList = new HashMap();     
    }
    dropTargetList.put(wid, dropCollection);
    if (banList == null) {
      banList = new Vector();
    }
  }
  
  /**
   * Adds a new DropListener to a non SourcesDropEvents Widget.
   * 
   * @param dropListener the listener to add on the Widget.
   */
  public void addDropListener(DropListener dropListener) {
    if (dropCollection != null) {
      dropCollection.add(dropListener, widget);
    }
  }
  
  /**
   * Remove a DropListener from a non SourcesDropEvents Widget.
   * 
   * @param dropListener the listener to add on the Widget.
   */
  public void removeDropListener(DropListener dropListener) {
    if (dropCollection != null) {
      dropCollection.remove(dropListener);
    }
  }
  
  /**
   * Adds a child to a DropTarget Widget. This will allow you to separate Widget, 
   * and allow to increase performance on your Drag, so that you may have less detection to do.
   * This is also important if you want to construct some Lists, and take advantage of Drop 
   * Target methods as Overflow, insertOnDrop or insertOnEnter.  
   * 
   * @param child the Widget to add in the container.
   */
  public void addToContainer(Widget child) {
    container = true;
    if (child instanceof SourcesDropEvents) {
      ((SourcesDropEvents) child).addDropListener(childListeners);
    } else if (dropTargetList.containsKey(child)) { 
      ((DropListenerCollection) dropTargetList.get(child)).add(childListeners, child);   
    } else {
      DropListenerCollection dropChild = new DropListenerCollection();
      dropChild.add(childListeners, child);
    }
    if (childMap == null) {
      childMap = new Vector();
    }
    Vector dropListenerMap = MouseDragGestureRecognizer.getDropMap();
    for (Iterator it =  dropListenerMap.iterator(); it.hasNext();) {
      DropListenerCollection dropListen = (DropListenerCollection) it.next();
      if (dropListen.getWidget().equals(child)) {
        childMap.add(dropListen);
        dropListenerMap.remove(dropListen);
        break;
      }
    }
  }
  
  /**
   * Insert a Widget into a list or a panel, automaticly in 
   * the position of the drag element when you release it.
   * 
   * @param insert true if you want to insert the drag Widget at the position of drop.
   */
  public void insertOnDrop(boolean insert) {
    insertOnDrop = insert;
  }
 
  /**
   * This method is usefull on the "insertOnEnter" method. Will allow you to delete the
   * blank label, only when the drag element will exit the target. Else, the blank label will
   * be remove each time you exit a simple item, and in the list, for example, it'll be up and down, 
   * time the drag element detect a new target.
   * 
   * @param exitTheTarget true on the DropTarget the Widget has to exit.
   */
  public void setExitTarget(boolean exitTheTarget) {
    this.exitTarget = true;
  }
  
  
  /**
   * Insert a blank label into a list, when a drag element enter it. the dragguing Widget will 
   * take the place of the pointed target.
   * 
   * @param insert true if you want to insert the Widget on enter a target.
   */
  public void insertOnEnter(boolean insert) {
    insertOnEnter = insert;
  }
  
  /**
   * Insert a dragWidget, at the place of a dropWidget, into his parent.
   * 
   * @param dropWidget the target Widget to take the place.
   * @param dragWidget the drag Widget to insert.
   */
  private void insertOnDrop(Widget dropWidget, Widget dragWidget) {
    Widget parent = dropWidget.getParent();
    if (insertOnDrop || insertOnEnter) {
      if (DragSource.checkParent(parent)) { 
        int index = DragSource.getIndex(dropWidget, parent);
        DOM.setStyleAttribute(dragWidget.getElement(), "position", "static");
        DragSource.addInto(dragWidget, parent , index);
      }
    }
  }
  
  /**
   * Insert a static blank Label in the width and height of a dragWidget. This Label will be
   * insert just before the dropWidget.
   * 
   * @param dropWidget the target to take the place of.
   * @param dragWidget the drag Widget to insert.
   */
  private void insertOnEnter(Widget dropWidget, Widget dragWidget) {
    Widget parent = dropWidget.getParent();
    if (insertOnEnter) {
      labelo.removeFromParent();
      if (DragSource.checkParent(parent)) { 
        int index = DragSource.getIndex(dropWidget, parent);
        DOM.setStyleAttribute(labelo.getElement(), "position", "static");
        labelo.setHeight(dragWidget.getOffsetHeight()+"");
        labelo.setWidth(dragWidget.getOffsetWidth()+"");
        DragSource.addInto(labelo, parent , index);
        labelo.setVisible(true);         
      }
    }
  }
  
  public void onDrop(Widget sender, Widget source) {  
  mouse = null;
  update = false;
  if (drop != null ) {
    if (MouseDragGestureRecognizer.detectDrop(left, right, top, bottom, drop)) {
      dropListener.fireDropOnDrop(drop, source);
      dragListener.fireDragOnDrop(source, drop);
      dropListener = null;
      drop = null;
      dragListener = null;
    } 
  }
  }

  public void onDropEnter(Widget sender, Widget source) {  
    if (banList.contains(source)) {
      container = false;
    } else {
      container = true;
    }
  }

  public void onDropExit(Widget sender, Widget source) {  
    if (drop != null && exit) {
      dropListener.fireOnDropExit(drop, source);
      dragListener.fireOnDragExit(source, drop);
      drop = null;
      dropListener = null;
      exit = false;
    }
    if (exitTarget) {
      labelo.removeFromParent();
    }
    mouse = null;
    update = false;
    dragListener = null;
  }

  /**
   * Disable a dropTarget for a dragHanlde. This is useFull if you set a drag Widget and put
   * drop Widget on it. This will allow you a panel, for example, to not detect his child.
   * 
   * @param dragHandle the dragHanlde which is moving.
   */
  public void disactivateDrop(Widget dragHandle) {
    banList.add(dragHandle);
  }
  
  /**
   * Allow you to control overflow from Widget which have scroll bar 
   * or a fix width and height.
   * 
   * @param overflowWidget the overflow max, that the widget cannot detect.
   */
  public void setWidgetOverflow(Widget overflowWidget) {
    overflow = overflowWidget;
  }
  
  public void onDropOver(Widget sender, Widget source) {  
  if (container) {
    exit = true;
    if (mouse == null) {
      mouse = MouseDragGestureRecognizer.getGestureMouse(source);     
      dragListener = mouse.getDragCollection();
    }
    Widget dragHandle = source; 
    if (mouse.getDragPadding()) {
      left = mouse.getPaddingLeft();
      top = mouse.getPaddingTop();
      right = mouse.getPaddingRight();
      bottom = mouse.getPaddingBottom();
    }
    if (drop == null && update) {
      for (Iterator it =  childMap.iterator(); it.hasNext();) {
        dropListener = (DropListenerCollection) it.next();
        Widget compare = dropListener.getWidget();
        if (MouseDragGestureRecognizer.detectDrop(left, right, top, bottom, compare)
            && dragHandle != compare) {
          drop = compare;
          if (drop != null && overflow != null && searchOverflow(overflow, drop)) {
              drop = null;
              if (insertOnEnter) {
                labelo.removeFromParent();
              }
          } 
          if (drop != null) {
            dropListener.fireOnDropEnter(drop, dragHandle);
            dragListener.fireOnDragEnter(dragHandle, drop);
          }
          break;
        }           
      } 
    }
    if (drop != null){
      if (MouseDragGestureRecognizer.detectDrop(left, right, top, bottom, drop)) {
        dropListener.fireOnDropOver(drop, dragHandle);
        dragListener.fireOnDragOver(dragHandle, drop);
      } else {
        dropListener.fireOnDropExit(drop, dragHandle);
        dragListener.fireOnDragExit(dragHandle, drop);
        exit = false;
        drop = null;
      }
    }
    if (!update) {
      this.updatePosition();
    }   
    update = mouse.getIsClic();
  } 
  }
  
  
  private boolean searchOverflow(Widget over, Widget drop) {
      Element overElem = over.getElement();
      int topFlow = DOM.getAbsoluteTop(overElem);
      int bottomFlow = topFlow + over.getOffsetHeight();           
      int leftFlow = DOM.getAbsoluteLeft(overElem);
      int rightFlow = leftFlow + over.getOffsetWidth();
      int leftDrop = DOM.getElementPropertyInt(drop.getElement(), "startLeft");
      int topDrop = DOM.getElementPropertyInt(drop.getElement(), "startTop");
      int compareTop = Math.min( bottomFlow, Math.max(topDrop, topFlow));
      int compareLeft = Math.min( rightFlow, Math.max(leftDrop, leftFlow));
      if (compareTop == bottomFlow || compareTop == topFlow || compareLeft == leftFlow || compareLeft == rightFlow) {
        return true;
      } else {
          return false;
        }
  }
  
  private void updatePosition() {
    for (Iterator it =  childMap.iterator(); it.hasNext();) {
      Element dropo = ((DropListenerCollection) it.next()).getWidget().getElement();
      DOM.setElementPropertyInt(dropo, "startWidth",  MouseDragGestureRecognizer.getWidth(dropo));
      DOM.setElementPropertyInt(dropo, "startHeight", MouseDragGestureRecognizer.getHeight(dropo));
      DOM.setElementPropertyInt(dropo, "startLeft",   DOM.getAbsoluteLeft(dropo));
      DOM.setElementPropertyInt(dropo, "startTop",    DOM.getAbsoluteTop(dropo));
    }  
  }
}

/*
 * Copyright 2007 Alex Gorisse.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.alex_gorisse.gwt.dragmovedrop;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.dnd.DragListener;
import com.google.gwt.user.client.dnd.DragListenerAdapter;
import com.google.gwt.user.client.dnd.MouseDragGestureRecognizer;
import com.google.gwt.user.client.dnd.SourcesDragEvents;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.DeckPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

import java.util.HashMap;

/**
 * This is the class for all Drag Behavior, around the different listener.
 * 
 * For example : 
 * <code>
 *  // First instantiate the manager
 *  DragSource.DragManager myManager = myDrag.getManager();
 *  // Then apply a behavior (this one allow you to drag a panel)
 *  myManager.setDraggle(myPan);
 * </code>
 * This class allows you to use all Drag behavior.
 * It is put in a class, to let the user instantiate himself the manager.<br>
 * Because it uses a addDragListener, this allows to gain in performance, if <br>
 * you don't have to use this manager, and wants to write your behavior.
 *
 */
public class DragSource implements DragListener {
  
  private MouseDragGestureRecognizer mouse, oldMouse;
  private boolean anime = false, goOut = false, insert = false, blockMove = false, replace = false;
  private int pad = 0, padLeft = 0, padRight = 0, padTop = 0, padBottom = 0, 
    padCopyLeft = 0, padCopyTop = 0, index = 0, leftWidget = 0, topWidget = 0 , 
    initialLeft = 0, initialTop = 0, initialInLeft = 0, initialInTop = 0;
  private Widget widget, newWidget = null, oldParent = null,  intoParent = null, newParent = null;
  private static HashMap dragSource; 
  
  private DragListenerAdapter listener = new DragListenerAdapter() {
    public void onDragEnd(Widget sender, int x, int y) {
      if (anime) {
        activeRestaure(true);
      }
    }
    public void onDragDropEnd(Widget sender, Widget target) {
      insertion(sender, target);
    }
  };

  /**
   * Constructor for {@link DragSource}.
   * @param wid the widget which receive a drag Events 
   */
  public DragSource(Widget wid) {
    this.widget = wid;
    if (widget instanceof SourcesDragEvents) {
      ((SourcesDragEvents) widget).addDragListener(this);
    } 
    mouse = MouseDragGestureRecognizer.getGestureMouse(widget);
    if (dragSource == null) {
      dragSource = new HashMap();
    }
    dragSource.put(widget, this);
  } 

  /**
   * Gets the current {@link DragSource}.
   * 
   * @param w the Widget targeted by the {@link DragSource}
   * @return the current {@link DragSource}
   */
  public static DragSource getDragSource(Widget w) {
    return (DragSource) dragSource.get(w);
  }
  
  /**
   * Gets the old parents, when a Widget leaves into an other. 
   * 
   * @return the last parent of copy, or Widget.
   */
  public Widget getOldParent() {
    return oldParent;
  } 
  
  /**
   * Allows you to drag an other widget. 
   * The handle widget, which is listening, must be in the widget to drag
   * 
   * @param widgetToMove the widget you want to move.
   */
  public void setDraggle(Widget widgetToMove) {
    mouse.setDrag(widgetToMove);
  }

  /**
   * Disable a widget to move.
   * 
   * @param move true if the widget move, else, false
   */
  public void setMove(boolean move) {
    mouse.setDragMove(move);
  }

  /**
   * Sets the padding detection of a drop target. 
   * 
   * @param padding in pixel, reduce on each side the area detection
   */
  public void setPadding(int padding) {
    if (padding != 0) {
      mouse.setPadding(padding);
    } 
  }

  /**
   * Sets the bottom padding detection of a drop Target.
   * 
   * @param padding in pixel, reduce the bottom area detection
   */
  public void setPaddingBottom(int padding) {
    padBottom = padding;  
  }

  /**
   * Sets the left padding detection of a drop Target.
   * 
   * @param padding in pixel, reduce the left area detection
   */
  public void setPaddingLeft(int padding) {
    padLeft = padding;  
  }

  /**
   * Sets the right padding detection of a drop Target.
   * 
   * @param padding in pixel, reduce the right area detection
   */
  public void setPaddingRight(int padding) {
    padRight = padding;  
  }

  /**
   * Sets the top padding detection of a drop Target.
   * 
   * @param padding in pixel, reduce the top area detection
   */
  public void setPaddingTop(int padding) {
    padTop = padding;  
  }

  /**
   * Restore a Widget to his initial parent and position with an effect animation.
   * 
   * @param restore true if the Widget go back to his last position, else false
   */
  public void animeAndRestaure(boolean restaure) {
    anime = restaure;
  }

  /**
   * Allows you to put out a Widget into an other panel onDragStart.
   * Necessary if you're using a vertical panel, instead the Widget will
   * place on a wrong area.
   * 
   * @param newParent the new Panel to add the widget.
   * @param goOut true if the Widget go out from his parent, else false
   */
  public void goOutParentInto(Widget newParent, boolean goOut) {
    this.goOut = goOut;
    this.newParent = newParent;
  } 

  /**
   * Copy a Widget in an other. 
   * The other one has his owns properties, and can be any other 
   * dragging family Widget.
   * 
   * @param newWidgetCopy the new copy Widget 
   * @param paddingLeft in pixel, sets the area left where the 
   * click will catch the copy. 0 if the area is the same than the Widget to copy
   * @param paddingTop in pixel, sets the area top where the 
   * click will catch the copy. 0 if the area is the same than the Widget to copy
   */
  private void copy(Widget newWidgetCopy, int paddingLeft, int paddingTop) {
    if (newWidgetCopy instanceof SourcesDragEvents) {
      this.newWidget = newWidgetCopy;
      newWidget.setVisible(false);
      ((SourcesDragEvents) newWidget).addDragListener(listener);
      oldMouse = mouse;
      mouse = MouseDragGestureRecognizer.getGestureMouse(newWidget);
      padCopyLeft = paddingLeft;
      padCopyTop = paddingTop;
    }
  }

  /**
   * Remove a copied Widget.
   */
  public void removeCopy() {
    if (newWidget != null) {
      newWidget.removeFromParent();
    }
  }

  /**
   * Copy a Widget into an other panel.
   * The copied Widget will be placed of the targeted panel.
   * 
   * @param newWidgetCopy the new copy Widget
   * @param newParent the panel to place the new Widget
   * @param paddingLeft in pixel, sets the area left where the 
   * click will catch the copy. 0 if the area is the same than the Widget to copy
   * @param paddingTop in pixel, sets the area top where the 
   * click will catch the copy. 0 if the area is the same than the Widget to copy
   */
  public void copyWidgetInto(Widget newWidgetCopy, Widget newParent, int paddingLeft, int paddingTop) {
    intoParent = newParent;
    this.copy(newWidgetCopy, paddingLeft, paddingTop);
  }

  /*
   * Intern method which restore a Widget to his initial position. 
   */
  private void activeRestaure(boolean copy) {
      this.getPosition(this.getWidget());
      restaure(this, this.getWidget().getElement(),
          leftWidget, topWidget, initialLeft, initialTop, 20, copy);
  }

  /*
   * Intern method which insert a Widget into a target on Drag End.
   */
  private void insertion(Widget sender, Widget target) {
    if (insert && target.getParent() instanceof VerticalPanel) {
      anime = false;
      Widget parent = target.getParent();
      index = this.getIndex(target, parent);   
      DOM.setStyleAttribute(sender.getElement(), "position", "static");
      this.addInto(sender, parent);
    }
  }
  
  public void onDragDropEnd(Widget sender, Widget target) {
    this.insertion(sender, target);
    if (replace) {
      labelo.setVisible(false);
    }
  }
  
  public void onDragOver(Widget sender, Widget target) {
  }

  public void onDragEnd(Widget sender, int x, int y) {
    if (anime) {
      this.activeRestaure(false); 
    }
  }
  private Label labelo = new Label("      ");
  
  public void onDragEnter(Widget sender, Widget target) {
      if (replace) {
        labelo.setHeight(mouse.getHeight(target.getElement()) + "");
        this.insertion(labelo, target);
        labelo.setVisible(true);
      }
  }

  public void onDragExit(Widget sender, Widget target) {
    if (replace) {
      labelo.setVisible(false);
    }
  }

  public void onDragMouseMoved(Widget sender, int x, int y) {
    if (padLeft != 0) {
      mouse.setPaddingLeft(mouse.getPaddingLeft() + padLeft);
    }
    if (padRight != 0) {
      mouse.setPaddingRight(mouse.getPaddingRight() - padRight);
    }
    if (padTop != 0) {
      mouse.setPaddingTop(mouse.getPaddingTop() + padTop);
    }
    if (padBottom != 0) {
      mouse.setPaddingBottom(mouse.getPaddingBottom() - padBottom);
    }
    if (blockMove) {
      Element dragElem = mouse.getDrag().getElement();
      Element dragParent = mouse.getDrag().getParent().getElement();     
      int leftParent =  mouse.getXoff() - mouse.getBorderLeft() ;
      int topParent =  mouse.getYoff() - mouse.getBorderTop() ;     
      int rightParent = leftParent + mouse.getWidth(dragParent) 
        - this.getBorderRight(dragParent) - mouse.getBorderLeft();   
      int bottomParent = topParent + mouse.getHeight(dragParent) 
        - this.getBorderBottom(dragParent) - mouse.getBorderTop();            
      int leftChild = x + mouse.getLeft(dragElem) ;
      int rightChild = rightParent - mouse.getWidth(dragElem);
      int topChild = y + mouse.getTop(dragElem) ;
      int bottomChild = bottomParent - mouse.getHeight(dragElem) ;       
      int maxLeft = Math.min(rightChild, Math.max(leftParent, leftChild));
      int maxTop = Math.min(bottomChild, Math.max(topParent , topChild));
      int left =  maxLeft + mouse.getBorderLeft() - mouse.getXoff();
      int top = maxTop + mouse.getBorderTop() - mouse.getYoff();    
      mouse.setWidgetPosition(mouse.getDrag(), left, top);
    }
  }

  public void onDragStart(Widget sender, int x, int y) {  
    this.getPosition(widget);
    if (this.checkParent(widget.getParent())) {
      index = getIndex(widget, widget.getParent()); 
    }
    if (anime) {
      initialLeft = leftWidget;
      initialTop = topWidget;
    }
    if (goOut) {
      initialInLeft = leftWidget;
      initialInTop = topWidget;
      oldParent = widget.getParent();
      intoParent = newParent;
      this.getPosition(widget);
      initialLeft = leftWidget;
      initialTop = topWidget;
      widget.removeFromParent();
      mouse.setWidgetPosition(widget, leftWidget, topWidget);
      this.addInto(widget, intoParent);
    }    
    if (newWidget != null) {
      DOM.releaseCapture(widget.getElement());
      oldMouse.setDragHandle(null);
      oldMouse.onMouseUp(widget, x, y);
      if (oldParent == null) {
        oldParent = widget.getParent();
      }
      this.addInto(newWidget, intoParent);
      int xInit = 0;
      int yInit = 0;
      if (padCopyLeft != 0) {
        xInit = x;
      }
      if (padCopyTop != 0) {
        yInit = y;
      }
      mouse.setWidgetPosition(newWidget,
          leftWidget + (xInit - padCopyLeft), 
          topWidget + (yInit - padCopyTop)) ;  
      newWidget.setVisible(true);
      mouse.onMouseDown(newWidget, x - (xInit - padCopyLeft), y - (yInit - padCopyTop));
      DOM.setCapture(newWidget.getElement());
    } 
  }

  public void detectAndInsert(VerticalPanel pan, boolean instantReplace) {
    insert = true;
    replace = instantReplace;
  }
 
  /**
   * Block a Widget into his parent. Works if you use the goOut method.
   * 
   * @param block true if the Widget must not leave his parent
   */
  public void blockMove(boolean block) {
    this.blockMove = block;
    if (blockMove) {
      mouse.setDragMove(false);
    } else {
      mouse.setDragMove(true);
    }
  }
  
  /*
   * Gets the current absolute position of Widget.
   */
  private void getPosition(Widget w) {
    Widget parent = null;
    Element child = w.getElement();
    if (intoParent != null) {
      parent = intoParent;
    } else if (w.getParent() != null) {
        parent = w.getParent();
      }
    leftWidget = DOM.getAbsoluteLeft(child) - MouseDragGestureRecognizer.getBorderLeft(child) ;
    topWidget = DOM.getAbsoluteTop(child) - MouseDragGestureRecognizer.getBorderTop(child) ;
    if (intoParent != RootPanel.get() && parent != null) {
      Element parentElem = parent.getElement();
      leftWidget -=  (DOM.getAbsoluteLeft(parentElem) + MouseDragGestureRecognizer.getBorderLeft(parentElem)) ;
      topWidget -=  (DOM.getAbsoluteTop(parentElem) + MouseDragGestureRecognizer.getBorderTop(parentElem)) ;   
    } 
  }

  /**
   * Gets The current dragged Widget.
   * 
   * @return the copied Widget if there is one, else the current Widget.
   */
  public Widget getWidget() {
    return newWidget != null ? newWidget : widget;
  }

  void reInsert() {
    if (goOut) { 
      mouse.setWidgetPosition(widget, initialInLeft, initialInTop);
      intoParent = null;     
      if (checkParent(oldParent)) {
        DOM.setStyleAttribute(widget.getElement(), "position", "static");
      }
      this.addInto(widget, oldParent);
    }
  }

  private native void restaure(DragSource source, Element elem, 
      int endX, int endY, int initX, int initY, int cpt, boolean copy) /*-{
    var increX = (initX - endX) / cpt;
    var increY = (initY - endY) / cpt;
    var newPosX = endX;
    var newPosY = endY;
    var cptEnd = 0;
    function restauration() {
      newPosX = newPosX + increX;
      newPosY = newPosY + increY;
      elem.style["left"] = newPosX;
      elem.style["top"] = newPosY;     
      if (cptEnd < cpt) {
        setTimeout(restauration,1);
        cptEnd++;
      }
      else {
        elem.style["left"] = initX;
        elem.style["top"] = initY;
        if (copy) {
          elem.style.display = false ? '' : 'none';
        }
       source.@com.alex_gorisse.gwt.dragmovedrop.DragSource::reInsert()();
      }
    }
    restauration();
  }-*/; 

  private static native int getScrollTop() /*-{
    return parseInt($doc.body.scrollTop);
  }-*/; 

  private static native int getScrollLeft() /*-{
    return parseInt($doc.body.scrollLeft);
  }-*/;  
  
  public static native int getBorderBottom(Element elem) /*-{
  if ($doc.defaultView != null) {
    var sElem = $doc.defaultView.getComputedStyle(elem, null);
    if (sElem != null) {
      var bBot = parseInt(sElem.getPropertyValue("border-bottom-width"));
      return bBot == -1 ? 0 : bBot;
    } 
  } 
  return 0;
  }-*/;
  
  public static native int getBorderRight(Element elem) /*-{
  if ($doc.defaultView != null) {
    var sElem = $doc.defaultView.getComputedStyle(elem, null);
    if (sElem != null) {
      var bRig = parseInt(sElem.getPropertyValue("border-right-width"));
      return bRig == -1 ? 0 : bRig;
    } 
  } 
  return 0;
  }-*/; 

  public static boolean checkParent(Widget w) {
    if (w instanceof DeckPanel) {
      return true;
    } else if (w instanceof HorizontalPanel) {
      return true;
    } else if (w instanceof VerticalPanel) {
      return true;
    } else {
      return false;
    }
  }

  public static void addInto(Widget child, Widget parent, int index) {
    if (parent instanceof AbsolutePanel) {
      ((AbsolutePanel) parent).add(child);
    } else if (parent instanceof DeckPanel) {
      ((DeckPanel) parent).insert(child, index);
    } else if (parent instanceof HorizontalPanel) {
      ((HorizontalPanel) parent).insert(child, index);
    } else if (parent instanceof VerticalPanel) {
      ((VerticalPanel) parent).insert(child, index);
    } else if (parent instanceof RootPanel) {
      ((RootPanel) parent).add(child);
    } else {
      throw new RuntimeException("Cannot insert into " + GWT.getTypeName(parent));
    }
  }
  
  private void addInto(Widget child, Widget parent) {
    if (parent instanceof AbsolutePanel) {
      ((AbsolutePanel) parent).add(child);
    } else if (parent instanceof DeckPanel) {
      ((DeckPanel) parent).insert(child, index);
    } else if (parent instanceof HorizontalPanel) {
      ((HorizontalPanel) parent).insert(child, index);
    } else if (parent instanceof VerticalPanel) {
      ((VerticalPanel) parent).insert(child, index);
    } else if (parent instanceof RootPanel) { 
      ((RootPanel) parent).add(child);
    } else {
      throw new RuntimeException("Cannot insert into " + GWT.getTypeName(parent));
    }
  }

  public static int getIndex(Widget child, Widget parent) {
    if (parent instanceof DeckPanel) {
      return ((DeckPanel) parent).getWidgetIndex(child);
    } else if (parent instanceof HorizontalPanel) {
        return ((HorizontalPanel) parent).getWidgetIndex(child);
    } else if (parent instanceof VerticalPanel) {
        return ((VerticalPanel) parent).getWidgetIndex(child);
    } else {
        return -1;
    }
  }
}
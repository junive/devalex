/*
 * Copyright 2007 sansrob@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package demoproject.client;

import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.DockPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.KeyboardListener;
import com.google.gwt.user.client.ui.KeyboardListenerAdapter;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

public class DemoPopup extends DialogBox implements ClickListener
{
	private Label lblAmnt = null;

	private TextBox tbAmnt = null;

	private Button okButton = null;

	private Button cancelButton = null;

	private GenGWTListBoxItem sourceWidget;

	private GenGWTListBox targetWidget;

	private String sAmount = "";

	private Widget modalWid = null;

	public DemoPopup(GenGWTListBoxItem source, GenGWTListBox target)
	{
		super(false, true);
		this.addStyleName("popup");
		sourceWidget = source;
		targetWidget = target;

		okButton = new Button("Ok", this);
		okButton.addStyleName("buttonpopup");
		cancelButton = new Button("Cancel", this);
		cancelButton.addStyleName("buttonpopup");
		tbAmnt = new TextBox();
		tbAmnt.addStyleName("textboxamount");
		sAmount = sourceWidget.getDBValue();
		setText(sourceWidget.getDisplayValue());
		lblAmnt = new Label("$" + sAmount);
		lblAmnt.addStyleName("labelamountdisplay");

		tbAmnt.addKeyboardListener(new KeyboardListenerAdapter()
		{
			public void onKeyPress(Widget sender, char keyCode, int modifiers)
			{
				if (keyCode == KeyboardListener.KEY_ENTER)
				{
					onClick(okButton);
				}
			}
		});

		DockPanel dockPanel = new DockPanel();

		VerticalPanel centerPanel = new VerticalPanel();
		centerPanel.setSpacing(10);
		HorizontalPanel amountDisplayPanel = new HorizontalPanel();
		amountDisplayPanel.setSpacing(1);
		Label label1 = new Label("Available Amount : ");
		label1.setWidth("110");
		label1.addStyleName("labelamount");
		amountDisplayPanel.add(label1);
		amountDisplayPanel.add(lblAmnt);
		amountDisplayPanel.setCellHorizontalAlignment(label1,
				HorizontalPanel.ALIGN_RIGHT);

		HorizontalPanel tbAmntPanel = new HorizontalPanel();
		tbAmntPanel.setSpacing(1);
		Label label2 = new Label("Transfer Amount : ");
		label2.addStyleName("labelenteramount");
		label2.setWidth("110");

		tbAmntPanel.add(label2);
		Label label3 = new Label("$");
		label3.addStyleName("labelenteramount");

		tbAmntPanel.add(label3);
		tbAmntPanel.add(tbAmnt);
		tbAmntPanel.setCellHorizontalAlignment(label2,
				HorizontalPanel.ALIGN_RIGHT);
		centerPanel.add(amountDisplayPanel);
		centerPanel.add(tbAmntPanel);

		HorizontalPanel btnPanel = new HorizontalPanel();
		btnPanel.setSpacing(10);
		btnPanel.add(okButton);
		btnPanel.add(cancelButton);
		btnPanel.setCellHorizontalAlignment(cancelButton,
				HorizontalPanel.ALIGN_RIGHT);

		dockPanel.add(btnPanel, DockPanel.SOUTH);
		dockPanel.add(centerPanel, DockPanel.CENTER);

		dockPanel.setCellHorizontalAlignment(btnPanel, DockPanel.ALIGN_RIGHT);
		setWidget(dockPanel);
		tbAmnt.setText(sAmount);
		tbAmnt.setFocus(true);
	}

	public void setSourceWidget(GenGWTListBoxItem source)
	{
		sourceWidget = source;
		sAmount = sourceWidget.getDBValue();
		lblAmnt.setText("$" + sAmount);
		tbAmnt.setFocus(true);
		tbAmnt.setText("");
	}

	public GenGWTListBoxItem getSourceWidget()
	{
		return this.sourceWidget;
	}

	public void setTargetWidget(GenGWTListBox target)
	{
		this.targetWidget = target;
	}

	public GenGWTListBox getTargetWidget()
	{
		return this.targetWidget;
	}

	public void setModalWidget(Widget wid)
	{
		this.modalWid = wid;
	}

	public Widget getModalWidget()
	{
		return this.modalWid;
	}

	public void onClick(Widget sender)
	{
		GenGWTListBoxItem targetListBoxItem = null;
		GenGWTListBoxItem sourceListBoxItem = null;
		GenGWTListBox sourceParentLB = sourceWidget.getParentListBox();

		if (sender == cancelButton)
		{
			sourceListBoxItem = DemoAppUtil.getNewListItem(sourceWidget,
					sourceParentLB);
			sourceParentLB.add(sourceListBoxItem, DemoAppUtil
					.getDraggedItemIndex());
		}
		else
			if (sender == okButton)
			{
				double avlAmount = Double.parseDouble(sAmount);
				double selAmount = 0;
				try
				{
					selAmount = Double.parseDouble(tbAmnt.getText());
				}
				catch (Exception e)
				{
					Window.alert("Please enter a valid amount.");
					this.setFocusOnAmountBox();
					return;
				}
				if (selAmount < 0)
				{
					Window.alert("Please enter a valid amount.");
					this.setFocusOnAmountBox();
					return;
				}
				if (selAmount > avlAmount)
				{
					Window.alert("Your entered amount should not"
							+ " be more than your available amount");
					this.setFocusOnAmountBox();
					return;
				}
				avlAmount = (Math.floor(avlAmount * 100)) / 100;
				selAmount = (Math.floor(selAmount * 100)) / 100;
				double updAmount = avlAmount - selAmount;
				updAmount = (Math.floor(updAmount * 100)) / 100;
				double targetDBValue = 0;
				double sourceDBValue = 0;
				if (updAmount == 0)
				{
					targetDBValue = avlAmount;
				}
				else
				{
					targetDBValue = selAmount;
					sourceDBValue = updAmount;

				}

				if (updAmount == 0)
				{
					targetListBoxItem = DemoAppUtil.getNewListItem(
							sourceWidget, targetWidget);
					DemoAppUtil.modifyOrAddItem(targetListBoxItem,
							targetWidget, targetDBValue);
				}
				else
				{
					sourceListBoxItem = DemoAppUtil.getCopyOfListItem(
							sourceWidget, sourceParentLB);
					targetListBoxItem = DemoAppUtil.getNewListItem(
							sourceWidget, targetWidget);

					DemoAppUtil.modifyOrAddItem(targetListBoxItem,
							targetWidget, targetDBValue);
					DemoAppUtil.modifyListBoxItem(sourceListBoxItem,
							sourceDBValue);
					sourceParentLB.add(sourceListBoxItem, DemoAppUtil
							.getDraggedItemIndex());
				}
			}
		DemoAppUtil.setDraggedItemIndex(-1);
		DemoAppUtil.setLastEnteredListBox(null);
		RootPanel.get().remove(this.getModalWidget());
		RootPanel.get().remove(this);
		DemoAppUtil.updateTotals();
	}

	public void setFocusOnAmountBox()
	{
		this.tbAmnt.setFocus(true);
	}
}

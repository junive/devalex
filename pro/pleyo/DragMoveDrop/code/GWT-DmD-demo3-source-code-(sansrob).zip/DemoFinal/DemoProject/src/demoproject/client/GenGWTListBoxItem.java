/*
 * Copyright 2007 sansrob@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package demoproject.client;

import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.MouseListenerAdapter;
import com.google.gwt.user.client.ui.Widget;

public class GenGWTListBoxItem extends Label
{

	private static final String STYLENAME_GENGWTLISTBOXITEM_HAS_VALUE = "gengwtlistboxitem_has_value";

	private static final String STYLENAME_GENGWTLISTBOXITEM = "gengwtlistboxitem";

	private static final String STYLENAME_GENGWTLISTBOXITEM_SELECTED = "gengwtlistboxitem_selected";

	private boolean selected = false;

	private String dbValue = "";

	private String displayValue = "";

	private String uniqueID = "";

	private GenGWTListBox parentListBox;

	public GenGWTListBoxItem()
	{
		this("", "");
	}

	public GenGWTListBoxItem(String inDisplayText, String inDBText)
	{
		super(inDisplayText);
		this.displayValue = inDisplayText;
		this.dbValue = inDBText;
		this.addMouseListener(new MouseListenerAdapter()
		{
			public void onMouseDown(Widget sender, int x, int y)
			{
				GenGWTListBoxItem item = (GenGWTListBoxItem) sender;
				item.setSelected(!item.isSelected());
			}
		});
		if (inDisplayText != null && inDisplayText.length() > 0)
		{
			addStyleName(STYLENAME_GENGWTLISTBOXITEM_HAS_VALUE);
		}
		else
		{
			addStyleName(STYLENAME_GENGWTLISTBOXITEM);
		}
	}

	public void setUniqueID(String inID)
	{
		this.uniqueID = inID;
	}

	public String getUniqueID()
	{
		return this.uniqueID;
	}

	public GenGWTListBoxItem cloneItemWithoutParent()
	{
		GenGWTListBoxItem clone = new GenGWTListBoxItem(this.displayValue,
				this.dbValue);
		clone.setUniqueID(this.getUniqueID());
		return clone;
	}

	public boolean isSelected()
	{
		return this.selected;
	}

	public void setSelected(boolean selected)
	{
		this.selected = selected;
		if (selected)
		{
			this.addStyleName(STYLENAME_GENGWTLISTBOXITEM_SELECTED);
		}
		else
		{
			removeStyleName(STYLENAME_GENGWTLISTBOXITEM_SELECTED);
		}
	}

	public void hideObject()
	{
		this.removeStyleName(STYLENAME_GENGWTLISTBOXITEM_HAS_VALUE);
		this.removeStyleName(STYLENAME_GENGWTLISTBOXITEM);
		this.removeStyleName(STYLENAME_GENGWTLISTBOXITEM_SELECTED);
		this.setPixelSize(0, 0);
		this.setVisible(false);
	}

	public String getDBValue()
	{
		if (this.dbValue == null)
		{
			return "";
		}
		return this.dbValue;
	}

	public String getDisplayValue()
	{
		if (this.displayValue == null)
		{
			return "";
		}
		return this.displayValue;
	}

	public void setDisplayValue(String inVal)
	{
		if (inVal != null)
		{
			this.displayValue = inVal;
			this.setText(inVal);
		}
	}

	public void setDBValue(String inVal)
	{
		if (inVal != null)
		{
			this.dbValue = inVal;
		}

	}

	public GenGWTListBox getParentListBox()
	{
		return this.parentListBox;
	}

	public void setParentListBox(GenGWTListBox inListBox)
	{
		this.parentListBox = inListBox;
	}
}

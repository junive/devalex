/*
 * Copyright 2007 sansrob@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package demoproject.client;

import java.util.Vector;

import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.ui.Label;

public class DemoAppUtil
{

	private static Vector destLists;

	private static int draggedItemIndex;

	private static GenGWTListBox lastEnteredListBox = null;

	private static Vector labelLists;

	public static void setDraggedItemIndex(int index)
	{
		draggedItemIndex = index;
	}

	public static int getDraggedItemIndex()
	{
		return draggedItemIndex;
	}

	public static void setLastEnteredListBox(GenGWTListBox listBox)
	{
		lastEnteredListBox = listBox;
	}

	public static GenGWTListBox getLastEnteredListBox()
	{
		return lastEnteredListBox;
	}

	public static void setDestListBoxes(Vector list)
	{
		destLists = list;
	}

	public static Vector getDestListBoxes()
	{
		return destLists;
	}

	public static void setLabelLists(Vector list)
	{
		labelLists = list;
	}

	public static Vector getLabelLists()
	{
		return labelLists;
	}

	public static void changeAllDestListBoxZIndex(String zIndex)
	{
		if (destLists != null)
		{
			for (int i = 0; i < destLists.size(); i++)
			{
				GenGWTListBox listBox = (GenGWTListBox) destLists.get(i);
				DOM.setStyleAttribute(listBox.getElement(), "zIndex", zIndex);
			}
		}
	}

	public static boolean isRegisteredItem(GenGWTListBox item)
	{
		if (item != null)
		{
			if (destLists != null)
			{
				for (int i = 0; i < destLists.size(); i++)
				{
					GenGWTListBox listBox = (GenGWTListBox) destLists.get(i);
					if (item == listBox)
					{
						return true;
					}
				}
			}
		}
		return false;
	}

	public static GenGWTListBoxItem getNewListItem(GenGWTListBoxItem item,
			GenGWTListBox source)
	{
		if (item != null)
		{
			GenGWTListBoxItem listItem = item.cloneItemWithoutParent();
			listItem.addDragListener(new LBAmountDragListener(source));
			item.hideObject();
			item.getParentListBox().removeItem(item);
			return listItem;
		}
		return item;
	}

	public static GenGWTListBoxItem getCopyOfListItem(GenGWTListBoxItem item,
			GenGWTListBox source)
	{
		if (item != null)
		{
			GenGWTListBoxItem listItem = item.cloneItemWithoutParent();
			listItem.addDragListener(new LBAmountDragListener(source));
			return listItem;
		}
		return item;
	}

	public static void modifyOrAddItem(GenGWTListBoxItem listItem,
			GenGWTListBox targetParentLB, double newDBVal)
	{
		for (int i = 0; i < targetParentLB.getItemCount(); i++)
		{
			GenGWTListBoxItem existingItem = targetParentLB.getItem(i);
			if (listItem.getUniqueID().equals(existingItem.getUniqueID()))
			{
				String targetDBValue = existingItem.getDBValue();
				double iVal = Double.parseDouble(targetDBValue);
				newDBVal = newDBVal + iVal;
				modifyListBoxItem(existingItem, newDBVal);
				listItem.hideObject();
				listItem = null;
				return;
			}
		}
		targetParentLB.add(getModifiedListBoxItem(listItem, newDBVal));
	}

	public static GenGWTListBoxItem getModifiedListBoxItem(
			GenGWTListBoxItem item, double newDBVal)
	{
		modifyListBoxItem(item, newDBVal);
		return item;
	}

	public static void modifyListBoxItem(GenGWTListBoxItem item, double newDBVal)
	{
		String sLabel = item.getDisplayValue();
		sLabel = sLabel.substring(0, sLabel.lastIndexOf('$'));
		sLabel = sLabel + "$" + newDBVal;
		item.setDBValue(String.valueOf(newDBVal));
		item.setDisplayValue(sLabel);
	}

	public static void updateTotals()
	{
		Vector boxList = DemoAppUtil.getDestListBoxes();
		Vector labelList = DemoAppUtil.getLabelLists();
		for (int i = 0; i < boxList.size(); i++)
		{
			GenGWTListBox box = (GenGWTListBox) boxList.get(i);
			double iTotal = 0;
			for (int j = 0; j < box.getItemCount(); j++)
			{
				GenGWTListBoxItem item = (GenGWTListBoxItem) box.getItem(j);
				try
				{
					iTotal = iTotal + Double.parseDouble(item.getDBValue());
				}
				catch (Exception e)
				{
				}
			}
			Label label = (Label) labelList.get(i);
			label.setText("Total - $" + iTotal);
		}
	}
}

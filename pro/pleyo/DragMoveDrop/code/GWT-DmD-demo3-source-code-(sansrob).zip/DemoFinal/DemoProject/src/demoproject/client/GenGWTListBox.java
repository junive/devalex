/*
 * Copyright 2007 sansrob@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package demoproject.client;

import com.google.gwt.user.client.ui.FocusPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

public class GenGWTListBox extends FocusPanel
{

	private static final String STYLENAME_GENGWTLISTBOX = "gengwtlistbox";

	private VerticalPanel verticalPanel = new VerticalPanel();

	private int itemCount = 0;

	private String uniqueID = "";

	public GenGWTListBox()
	{
		addStyleName(STYLENAME_GENGWTLISTBOX);
		super.add(verticalPanel);
	}

	public void add(String inDisplayVal)
	{
		this.add(inDisplayVal, inDisplayVal);
	}

	public void add(String inDisplayVal, String inDBVal)
	{
		this.add(inDisplayVal, inDBVal, (verticalPanel.getWidgetCount()));
	}

	public void add(String inDisplayVal, String inDBVal, int beforeIndex)
	{
		GenGWTListBoxItem item = new GenGWTListBoxItem(inDisplayVal, inDBVal);
		this.add(item, beforeIndex);
	}

	public void add(GenGWTListBoxItem genGWTListBoxItem)
	{
		if (genGWTListBoxItem != null)
		{
			this.add(genGWTListBoxItem, (verticalPanel.getWidgetCount()));
		}
	}

	public void add(GenGWTListBoxItem genGWTListBoxItem, int beforeIndex)
	{
		if (genGWTListBoxItem != null)
		{
			if (itemCount <= 0)
			{
				verticalPanel.add(genGWTListBoxItem);
			}
			else
			{
				if (beforeIndex < 0)
				{
					verticalPanel.add(genGWTListBoxItem);
				}
				else
					if (beforeIndex > itemCount)
					{
						verticalPanel.add(genGWTListBoxItem);
					}
					else
					{
						verticalPanel.insert(genGWTListBoxItem, beforeIndex);
					}
			}
			genGWTListBoxItem.setParentListBox(this);
			itemCount++;
		}
	}

	public int getSelectedItemCount()
	{
		int count = 0;
		for (int i = 0; i < itemCount; i++)
		{
			if (isItemSelected(i))
			{
				count++;
			}
		}
		return count;
	}

	public int getItemIndex(GenGWTListBoxItem inItem)
	{
		for (int i = 0; i < itemCount; i++)
		{
			GenGWTListBoxItem item = (GenGWTListBoxItem) verticalPanel
					.getWidget(i);
			if (item == inItem)
			{
				return i;
			}
		}
		return -1;
	}

	public GenGWTListBoxItem getItem(int index)
	{
		this.checkIndex(index);
		GenGWTListBoxItem item = (GenGWTListBoxItem) verticalPanel
				.getWidget(index);
		return item;
	}

	public int getItemCount()
	{
		return itemCount;
	}

	public boolean isItemSelected(int index)
	{
		this.checkIndex(index);
		GenGWTListBoxItem item = (GenGWTListBoxItem) verticalPanel
				.getWidget(index);
		return item.isSelected();
	}

	public void removeItem(int index)
	{
		this.checkIndex(index);
		verticalPanel.remove(index);
		itemCount--;
	}

	public void removeItem(GenGWTListBoxItem item)
	{
		try
		{
			verticalPanel.remove(item);
			itemCount--;
		}
		catch (Exception e)
		{
		}
	}

	public void setHeight(String height)
	{
		super.setHeight(height);
	}

	public void setItemSelected(int index, boolean selected)
	{
		GenGWTListBoxItem item = (GenGWTListBoxItem) verticalPanel
				.getWidget(index);
		item.setSelected(selected);
	}

	public void setPixelSize(int width, int height)
	{
		super.setPixelSize(width, height);
		String sWidth = "" + width + "px";
		verticalPanel.setWidth(sWidth);
		this.setWidthForItems(sWidth);
	}

	public void setWidth(String width)
	{
		super.setWidth(width);
		verticalPanel.setWidth(width);
		this.setWidthForItems(width);
	}

	private void setWidthForItems(String inWidth)
	{
		for (int i = 0; i < itemCount; i++)
		{
			GenGWTListBoxItem item = (GenGWTListBoxItem) verticalPanel
					.getWidget(i);
			item.setWidth(inWidth);
		}
	}

	public String getDBValue(int index)
	{
		this.checkIndex(index);
		GenGWTListBoxItem item = (GenGWTListBoxItem) verticalPanel
				.getWidget(index);
		return item.getDBValue();
	}

	public String getDisplayValue(int index)
	{
		this.checkIndex(index);
		GenGWTListBoxItem item = (GenGWTListBoxItem) verticalPanel
				.getWidget(index);
		return item.getDisplayValue();
	}

	private void checkIndex(int index)
	{
		if (index < 0 || index >= itemCount)
		{
			throw new IllegalArgumentException("Index out of range " + index);
		}
	}

	public GenGWTListBox cloneItem()
	{
		GenGWTListBox newListBox = new GenGWTListBox();
		for (int i = 0; i < this.getItemCount(); i++)
		{
			GenGWTListBoxItem listItem = this.getItem(i);
			GenGWTListBoxItem newListItem = listItem.cloneItemWithoutParent();
			newListBox.add(newListItem);
		}
		return newListBox;
	}

	public void setUniqueID(String inID)
	{
		this.uniqueID = inID;
	}

	public String getUniqueID()
	{
		return this.uniqueID;
	}

}

/*
 * Copyright 2007 sansrob@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package demoproject.client;

import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.dnd.DragListener;
import com.google.gwt.user.client.dnd.MouseDragGestureRecognizer;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.FocusPanel;

public class LBAmountDragListener implements DragListener
{

	private GenGWTListBox sourceListBox;
	
	public LBAmountDragListener(GenGWTListBox sourceListBox)
	{
		this.sourceListBox = sourceListBox;
	}

	public void setSourceListBox(GenGWTListBox inListBox)
	{
		this.sourceListBox = inListBox;
	}

	public GenGWTListBox getSourceListBox()
	{
		return this.sourceListBox;
	}

	public void onDragDropEnd(Widget sender, Widget target)
	{
	}

	public void onDragEnd(Widget sender, int x, int y)
	{
		GenGWTListBoxItem item = (GenGWTListBoxItem) sender;
		item.removeStyleName("selecteditemwidth");
		if ((DemoAppUtil.getLastEnteredListBox() == null)
				|| (!DemoAppUtil.isRegisteredItem(DemoAppUtil
						.getLastEnteredListBox()))
				|| (item.getParentListBox() == DemoAppUtil
						.getLastEnteredListBox()))

		{
			if (DemoAppUtil.getDraggedItemIndex() != -1)
			{
				this.getSourceListBox().add(
						DemoAppUtil.getNewListItem(item, this
								.getSourceListBox()),
						DemoAppUtil.getDraggedItemIndex());
			}

		}
		FocusPanel fp = new FocusPanel();
		fp.setPixelSize(5,5);
		RootPanel.get().add(fp);
		RootPanel.get().remove(fp);
	}

	public void onDragEnter(Widget sender, Widget target)
	{
		DemoAppUtil.setLastEnteredListBox((GenGWTListBox) target);
	}

	public void onDragExit(Widget sender, Widget target)
	{
		DemoAppUtil.setLastEnteredListBox(null);
	}

	public void onDragMouseMoved(Widget sender, int x, int y)
	{
	}

	public void onDragOver(Widget sender, Widget target)
	{
	}

	public void onDragStart(Widget sender, int x, int y)
	{
		GenGWTListBoxItem item = (GenGWTListBoxItem) sender;
		MouseDragGestureRecognizer mouse = MouseDragGestureRecognizer
				.getGestureMouse(item);
		int left = DOM.getAbsoluteLeft(item.getParentListBox().getParent().getParent().getElement());
		int left1 = DOM.getAbsoluteLeft(item.getParentListBox().getElement());
		int elemLeft = (left1 - left);
		int top = DOM.getAbsoluteTop(item.getParentListBox().getParent().getParent().getElement());
		int top1 = DOM.getAbsoluteTop(item.getElement());
		
		int elemTop = top1 - top;
		mouse.setWidgetPosition(item, elemLeft -3 , elemTop -3);

		DOM.setStyleAttribute(item.getElement(), "zIndex", "2");
		int itemIndex = this.getSourceListBox().getItemIndex(item);
		DemoAppUtil.setDraggedItemIndex(itemIndex);
		DemoAppUtil.setLastEnteredListBox(null);
		if (item.isSelected())
		{
			item.addStyleName("selecteditemwidth");
		}
	}
}

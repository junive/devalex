/*
 * Copyright 2007 sansrob@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package demoproject.client;

import java.util.Vector;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.EventPreview;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class DemoApplication implements EntryPoint
{

	public void onModuleLoad()
	{
		AbsolutePanel aPanel = new AbsolutePanel();
		AbsolutePanel emptyPanel = new AbsolutePanel();
		emptyPanel.setPixelSize(150, 120);

		aPanel.setPixelSize(570, 600);
		HorizontalPanel hPanel = new HorizontalPanel();
		hPanel.addStyleName("panelmain");
		VerticalPanel leftPanel = new VerticalPanel();
		leftPanel.setSpacing(17);
		VerticalPanel middlePanel = new VerticalPanel();
		middlePanel.setSpacing(17);
		VerticalPanel rightPanel = new VerticalPanel();
		rightPanel.setSpacing(17);

		GenGWTListBox amountListBox = new GenGWTListBox();

		GenGWTListBox accountListBox1 = new GenGWTListBox();
		GenGWTListBox accountListBox2 = new GenGWTListBox();
		GenGWTListBox accountListBox3 = new GenGWTListBox();
		GenGWTListBox accountListBox4 = new GenGWTListBox();

		Vector boxLists = new Vector();
		boxLists.add(accountListBox1);
		boxLists.add(accountListBox2);
		boxLists.add(accountListBox3);
		boxLists.add(accountListBox4);
		boxLists.add(amountListBox);

		DemoAppUtil.setDestListBoxes(boxLists);

		LBAmountDragListener amountDragListener = new LBAmountDragListener(
				amountListBox);
		LBAccountDropListener accountDropListener = new LBAccountDropListener();

		amountListBox.addDropListener(accountDropListener);
		accountListBox1.addDropListener(accountDropListener);
		accountListBox2.addDropListener(accountDropListener);
		accountListBox3.addDropListener(accountDropListener);
		accountListBox4.addDropListener(accountDropListener);

		amountListBox.setPixelSize(150, 200);
		accountListBox1.setPixelSize(150, 200);
		accountListBox2.setPixelSize(150, 200);
		accountListBox3.setPixelSize(150, 200);
		accountListBox4.setPixelSize(150, 200);

		Vector labelList = new Vector();

		Label acctLabel1 = new Label("Account 1");
		acctLabel1.setPixelSize(150, 10);
		acctLabel1.addStyleName("labelaccount");
		acctLabel1.setHorizontalAlignment(Label.ALIGN_LEFT);
		leftPanel.add(acctLabel1);

		leftPanel.add(accountListBox1);
		Label label1 = new Label("Total - ");
		label1.setPixelSize(150, 20);
		label1.addStyleName("labeltotal");
		label1.setHorizontalAlignment(Label.ALIGN_RIGHT);
		leftPanel.add(label1);
		Label acctLabel3 = new Label("Account 3");
		acctLabel3.setPixelSize(150, 10);
		acctLabel3.addStyleName("labelaccount");
		acctLabel3.setHorizontalAlignment(Label.ALIGN_LEFT);
		leftPanel.add(acctLabel3);

		leftPanel.add(accountListBox3);

		Label label3 = new Label("Total - ");
		label3.setPixelSize(150, 20);
		label3.addStyleName("labeltotal");
		label3.setHorizontalAlignment(Label.ALIGN_RIGHT);
		leftPanel.add(label3);

		middlePanel.add(emptyPanel);

		Label acctLabel5 = new Label("Common Account");
		acctLabel5.setPixelSize(150, 10);
		acctLabel5.addStyleName("labelaccount");
		acctLabel5.setHorizontalAlignment(Label.ALIGN_LEFT);
		middlePanel.add(acctLabel5);
		middlePanel.add(amountListBox);

		Label label5 = new Label("Total - $340");
		label5.setPixelSize(150, 20);
		label5.addStyleName("labeltotal");
		label5.setHorizontalAlignment(Label.ALIGN_RIGHT);
		middlePanel.add(label5);

		Label acctLabel2 = new Label("Account 2");
		acctLabel1.setPixelSize(150, 10);
		acctLabel2.addStyleName("labelaccount");
		acctLabel2.setHorizontalAlignment(Label.ALIGN_LEFT);
		rightPanel.add(acctLabel2);
		rightPanel.add(accountListBox2);

		Label label2 = new Label("Total - ");
		label2.setPixelSize(150, 20);
		label2.addStyleName("labeltotal");
		label2.setHorizontalAlignment(Label.ALIGN_RIGHT);
		rightPanel.add(label2);

		Label acctLabel4 = new Label("Account 4");
		acctLabel1.setPixelSize(150, 10);
		acctLabel4.addStyleName("labelaccount");
		acctLabel4.setHorizontalAlignment(Label.ALIGN_LEFT);
		rightPanel.add(acctLabel4);

		rightPanel.add(accountListBox4);

		Label label4 = new Label("Total - ");
		label4.setPixelSize(150, 20);
		label4.addStyleName("labeltotal");
		label4.setHorizontalAlignment(Label.ALIGN_RIGHT);
		rightPanel.add(label4);

		labelList.add(label1);
		labelList.add(label2);
		labelList.add(label3);
		labelList.add(label4);
		labelList.add(label5);

		DemoAppUtil.setLabelLists(labelList);
		amountListBox.add("ABC DRUGS - $50", "50");
		amountListBox.add("WALMART - $30", "30");
		amountListBox.add("SOME PHARMACY - $20", "20");
		amountListBox.add("WALGREENS - $44", "44");
		amountListBox.add("SOME DIAGNOS - $15", "15");
		amountListBox.add("SOME STORE - $60", "60");
		amountListBox.add("OTHER - $25", "25");
		amountListBox.add("SOME DAYCARE - $20", "20");
		amountListBox.add("SOME SHOP - $33", "33");
		amountListBox.add("OTHER MEDICAL - $43", "43");
		for (int i = 0; i < amountListBox.getItemCount(); i++)
		{
			GenGWTListBoxItem item = (GenGWTListBoxItem) amountListBox
					.getItem(i);
			item.setUniqueID(String.valueOf(i));
			item.addDragListener(amountDragListener);
		}
		hPanel.add(leftPanel);
		hPanel.add(middlePanel);
		hPanel.add(rightPanel);
		aPanel.add(hPanel, 0, 0);
		RootPanel.get().add(aPanel, 50, 30);

		DOM.addEventPreview(new EventPreview()
		{
			public boolean onEventPreview(Event event)
			{
				if (DOM.eventGetType(event) == Event.ONMOUSEDOWN)
				{
					DOM.eventPreventDefault(event);
				}
				return true;
			}
		});
	}
}
